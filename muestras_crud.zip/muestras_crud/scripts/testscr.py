from visualizaciones import graphs_main

graphs_main(r"C:\QCdata\Reports\PAH_report_01.xlsx")